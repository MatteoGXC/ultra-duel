--カオス・ソルジャー
function c10000100.initial_effect(c)
	aux.AddCodeList(c,55761792)
	c:EnableReviveLimit()
end
